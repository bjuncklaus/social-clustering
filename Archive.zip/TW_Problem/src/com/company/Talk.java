package com.company;

public class Talk implements Comparable{
    private String title;
    private String name;
    private Integer timeDuration;
    boolean scheduled = false;
    String scheduledTime;

    public Talk(String title, String name, int time) {
        this.title = title;
        this.name = name;
        this.timeDuration = time;
    }

    public void setScheduled(boolean scheduled) {
        this.scheduled = scheduled;
    }

    public boolean isScheduled() {
        return scheduled;
    }

    public void setScheduledTime(String scheduledTime) {
        this.scheduledTime = scheduledTime;
    }

    public Integer getTimeDuration() {
        return timeDuration;
    }

    public String getTitle() {
        return title;
    }


//     Sort data in descending order.

    @Override
    public int compareTo(Object obj)
    {
        Talk talk = (Talk)obj;
        return talk.getTimeDuration().compareTo(this.getTimeDuration());
    }
}



package com.company;

public class InvalidTalkException extends Exception {
    public InvalidTalkException(String message) {
        super(message);
    }
}

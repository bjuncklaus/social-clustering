package com.schedule.conferece;

import java.util.List;

import com.schedule.conferece.parse.Reader;
import com.schedule.conferece.schedule.Scheduler;

public class Main {

    public static void main(String[] args) {
        Reader reader = new Reader();
        List<String> processedTalks = reader.processInputTalks();
        try {
        	Scheduler scheduler = Scheduler.getScheduler(reader.getTalkList(processedTalks));
        	scheduler.scheduleConferenceWithInformationFromFile();
        } catch (RuntimeException e) {
			System.out.println("Invalid input!");
			System.exit(1);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
    }
}

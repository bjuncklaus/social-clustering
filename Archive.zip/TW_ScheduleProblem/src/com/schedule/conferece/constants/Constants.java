package com.schedule.conferece.constants;

public class Constants {

	public static String FILENAME = "dataset/dataset.txt";
	public static Integer TOTAL_AVAILABLE_MINUTES = 6 * 60;
	
}

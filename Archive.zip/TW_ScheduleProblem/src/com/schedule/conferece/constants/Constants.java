package com.schedule.conferece.constants;

public class Constants {

	public static String FILENAME = "dataset/dataset.txt";
	
}

package com.schedule.conferece;

import java.util.ArrayList;
import java.util.List;

import com.schedule.conferece.constants.Constants;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;

public class Reader {
	
	public List<String> processTalks() {
		List<String> talks = new ArrayList<String>();
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader(Constants.FILENAME));
			String line = bufferedReader.readLine();
			
			while (line != null) {
				talks.add(line);
				line = bufferedReader.readLine();
			}
			bufferedReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return talks;
	}

	public List<Talk> createValidTalks(List<String> talkList) throws Exception {
		// If talksList is null throw exception invalid list to schedule.
		if(talkList == null)
			throw new RuntimeException("Empty Talk List");

		List<Talk> validTalksList = new ArrayList<Talk>();
		String minSuffix = "min";
		String lightningSuffix = "lightning";

		// Iterate list and validate time.
		for(String talk : talkList)
		{
			int lastSpaceIndex = talk.lastIndexOf(" ");
			// if talk does not have any space, means either title or time is missing.
			if(lastSpaceIndex == -1)
				throw new RuntimeException("Invalid talk: " + talk + ". Invalid talk time.");

			String title = talk.substring(0, lastSpaceIndex);
			String timeStr = talk.substring(lastSpaceIndex + 1);
			// If title is missing or blank.
			if(title == null || "".equals(title.trim()))
				throw new RuntimeException("Invalid talk name: " + talk);
			// If time is not ended with min or lightning.
			else if(!timeStr.endsWith(minSuffix) && !timeStr.endsWith(lightningSuffix))
				throw new RuntimeException("Invalid talk time: " + talk + ". Enter time in min or in lightning");

			int time = 0;
			// Parse time from the time string .
			try{
				if(timeStr.endsWith(minSuffix)) {
					time = Integer.parseInt(timeStr.substring(0, timeStr.indexOf(minSuffix)));
				}
				else if(timeStr.endsWith(lightningSuffix)) {
					String lightningTime = timeStr.substring(0, timeStr.indexOf(lightningSuffix));
					if("".equals(lightningTime))
						time = 5;
					else
						time = Integer.parseInt(lightningTime) * 5;
				}
			}catch(NumberFormatException e) {
				throw new RuntimeException("Unable to get time information from file.  Error on time: " + timeStr + " for talk " + talk);
			}
			// Add talk to the valid talk List.
			validTalksList.add(new Talk(title, time));
		}
		return validTalksList;
	}

	public ConferenceManager buildScheduledSetUp() {
		List<String> talkList = getTalksFromFile(Constants.FILENAME);
		List<Talk> talksValidList = null;
		try {
			talksValidList = createValidTalks(talkList);
		} catch (RuntimeException e) {
			System.out.println("Invalid input from file");
		} catch (Exception e) {
			e.printStackTrace();
		}
		ConferenceManager conferenceManager = new ConferenceManager(talksValidList);
		return conferenceManager;
	}
}
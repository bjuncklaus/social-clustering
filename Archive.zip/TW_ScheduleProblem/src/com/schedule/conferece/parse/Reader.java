package com.schedule.conferece.parse;

import java.util.ArrayList;
import java.util.List;

import com.schedule.conferece.constants.Constants;
import com.schedule.conferece.entity.Talk;
import com.schedule.conferece.schedule.Scheduler;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;

public class Reader {

	public List<String> processInputTalks() {
		List<String> talks = new ArrayList<String>();
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader(Constants.FILENAME));
			String line = bufferedReader.readLine();

			while (line != null) {
				talks.add(line);
				line = bufferedReader.readLine();
			}
			bufferedReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return talks;
	}

	public List<Talk> getTalkList(List<String> talks) throws Exception {
		List<Talk> talkList = new ArrayList<Talk>();
		
		if (talks != null) {
			String min = "min";
			String lightning = "lightning";
			
			for(String talk : talks) {
				int lastBlankSpaceIndex = talk.lastIndexOf(" ");
				
				if (lastBlankSpaceIndex > 0) {
					String title = talk.substring(0, lastBlankSpaceIndex);
					String titleTime = talk.substring(lastBlankSpaceIndex + 1);
					
					if (title != null && !title.trim().isEmpty()) {
						int talkTime = getTalkTime(min, lightning, talk, titleTime);
						talkList.add(new Talk(title, talkTime));
					} else if (!titleTime.contains(min) && !titleTime.contains(lightning)) {
						throw new RuntimeException("Missing time information on talk. Please add the 'min' or 'lightning' information to the talk: " + talk);
					} else {
						throw new RuntimeException("Missing talk title for talk: " + talk);
					}
				} else {
					throw new RuntimeException("Invalid time. Talk: " + talk);
				}
			}
		} else {
			throw new RuntimeException("Invalid processed talks.");
		}
		return talkList;
	}

	public int getTalkTime(String min, String lightning, String talk, String titleTime) {
		int talkTime = 0;
		
		try {
			if (titleTime.endsWith(min)) {
				talkTime = Integer.parseInt(titleTime.substring(0, titleTime.indexOf(min)));
			} else if (titleTime.endsWith(lightning)) {
				String lightningTalkTime = titleTime.substring(0, titleTime.indexOf(lightning));
				talkTime = getLightningTalkTime(lightningTalkTime);
			}
		} catch (NumberFormatException e) {
			throw new RuntimeException("Error on getting the talk (" + talk + ") time (" + titleTime + ").");
		}
		
		return talkTime;
	}

	public int getLightningTalkTime(String lightningTalkTime) {
		int talkTime;
		
		if (lightningTalkTime.isEmpty()) {
			talkTime = 5;
		} else {
			talkTime = Integer.parseInt(lightningTalkTime) * 5;
		}
		return talkTime;
	}
}
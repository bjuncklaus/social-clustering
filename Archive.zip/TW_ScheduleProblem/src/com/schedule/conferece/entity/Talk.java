package com.schedule.conferece.entity;

public class Talk implements Comparable<Talk> {
	private String title;
	private Integer duration;
	private boolean scheduled;
	private String sessionTime;

	public Talk(String title, Integer time) {
		this.title = title;
		this.duration = time;
		this.scheduled = false;
	}

	public void setScheduled(boolean scheduled) {
		this.scheduled = scheduled;
	}

	public boolean isScheduled() {
		return scheduled;
	}

	public void setSessionTime(String sessionTime) {
		this.sessionTime = sessionTime;
	}
	
	public String getSessionTime() {
		return sessionTime;
	}

	public Integer getDuration() {
		return duration;
	}

	public String getTitle() {
		return title;
	}

	@Override
	public int compareTo(Talk talk) {
		return talk.getDuration().compareTo(this.getDuration());
	}
}


